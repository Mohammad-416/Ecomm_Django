document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('registrationForm').addEventListener('submit', function(event) {
        event.preventDefault();
        // Add your registration form submission logic here
        // You can use AJAX to send the form data to the server
        // Update the form to display success or error messages
    });
});
